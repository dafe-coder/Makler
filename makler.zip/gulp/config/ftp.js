export let configFTP = {
	host: 'eushared04.twinservers.net',
	user: 'aicespac',
	password: 'gV43Bj4cu4',
	parallel: 5,
}
